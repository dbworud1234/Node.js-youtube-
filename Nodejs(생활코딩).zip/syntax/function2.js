console.log(Math.round(1.6)); // Math는 자바스크립트 내부에 있는 객체이고 round라는 함수가 있음.
console.log(Math.round(1.4)); // round는 반올림임.

function sum(first, second){
  return first + second;
}

console.log(sum(2,4));
