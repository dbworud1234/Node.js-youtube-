console.log('1'+'1');
console.log('https://www.youtube.com/watch?v=De9Cttb_9dQ&list=PLfs-6fkBBhmh17wuQpoO7ZUhueyLa4wSY&index=10'.length)
